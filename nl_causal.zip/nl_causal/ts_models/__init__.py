from .ts_twas import _2SLS, _2SIR
import sys

sys.path.append('..')

__all__ = [
	"_2SLS", 
	"_2SIR"
	]